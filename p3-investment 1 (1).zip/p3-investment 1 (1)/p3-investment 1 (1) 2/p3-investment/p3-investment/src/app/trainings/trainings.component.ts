import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ColDef } from 'ag-grid-community';

@Component({
  selector: 'app-trainings',
  templateUrl: './trainings.component.html',
  styleUrls: ['./trainings.component.scss']
})
export class TrainingsComponent implements OnInit {


  rowData = [
    { SNo: "1", CourseName: "Angular", Timeline: "June", Status: "Completed" },
    { SNo: "2", CourseName: "React JS", Timeline: "July", Status: "Completed" },
    { SNo: "3", CourseName: "Vertex AI", Timeline: "July", Status: "Completed" },
    { SNo: "4", CourseName: "App Sheet", Timeline: "July", Status: "In Progress" },
    { SNo: "5", CourseName: "App Script", Timeline: "August", Status: "Planned" },
    { SNo: "6", CourseName: "GCP", Timeline: "September", Status: "Planned" }
  ];

  colDefs: ColDef[] = [
    { field: "SNo",headerName:'S.No' },
    { field: "CourseName",headerName:'Course Name',filter:true },
    { field: "Timeline",headerName:'Timeline' },
    { field: "Status",headerName:'Status' }
  ];

  defaultColDef = {
    flex:1,
    minWidth:100
  }
  constructor(private http: HttpClient) { }

  ngOnInit(): void {
  }

}
