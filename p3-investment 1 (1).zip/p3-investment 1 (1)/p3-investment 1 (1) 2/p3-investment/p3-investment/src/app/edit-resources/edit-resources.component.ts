import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-resources',
  templateUrl: './edit-resources.component.html',
  styleUrls: ['./edit-resources.component.scss']
})
export class EditResourcesComponent implements OnInit {

  roleList = ['Admin','Super Admin','User'];

  termList = ['M', 'SA', 'A', 'PA', 'PAT'];

  projectList = ['Egnos Swift', 'LogAnalyzer', 'Egnos'];

  onboardingStatus = ['Onboarded', 'In Progress', 'Released'];

  name!: string;

  constructor() { }

  ngOnInit(): void {
  }

}
