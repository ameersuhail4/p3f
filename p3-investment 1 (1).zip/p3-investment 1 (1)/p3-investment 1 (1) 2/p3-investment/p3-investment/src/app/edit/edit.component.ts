import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditComponent implements OnInit, ICellRendererAngularComp {

  constructor(private router: Router) { }

  ngOnInit(): void {}

  agInit(params: ICellRendererParams<any, any, any>): void {}

  refresh(params: ICellRendererParams<any, any, any>): boolean {
    return true;
  }

navigateTo() {
  this.router.navigate(['edit-resources']);
}
}
