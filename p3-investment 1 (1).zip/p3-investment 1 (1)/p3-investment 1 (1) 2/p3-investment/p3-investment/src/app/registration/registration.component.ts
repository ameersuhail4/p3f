import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {

  roles = ['Super Admin', 'Admin', 'Team Lead', 'User'];

  firstName!: string;

  constructor() { }

  ngOnInit(): void {
  }

}
