import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ColDef,GridApi,GridReadyEvent } from 'ag-grid-community';
import { EditResourcesComponent } from '../edit-resources/edit-resources.component';
import { EditComponent } from '../edit/edit.component';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-resources',
  templateUrl: './resources.component.html',
  styleUrls: ['./resources.component.scss']
})
export class ResourcesComponent implements OnInit {

  file: any;

  formData = new FormData();

  private gridApi!: GridApi<any>;

  userList: any = [];

  resourceDetails: any = [];

  colDefs: any = [];

  // colDefs = [
  //   { field: "id", headerName:'Emp ID',
  //     cellRenderer:(item:any)=>{
  //       return "EMP-"+ item.value
  //     }
  //   },
  //   { field: "name", headerName: 'Name', filter:'agTextColumnFilter' },
  //   { field: "designation", headerName: 'Designation' },
  //   { field: "onboarding", headerName: 'Onboarding Status' },
  //   { field: "billing", headerName: 'Billing Status' },
  //   { field: "manager", headerName: 'Manager' },
  //   { field: 'action', headerName: 'Actions', cellRenderer: EditComponent},
  // ];

  defaultColDef = {
    flex:1,
    minWidth:152
  }
  constructor(private http: HttpClient, private toastr: ToastrService, private commonService: CommonService) { }

  ngOnInit(): void {
  }

  onBtExport() {
    this.gridApi.exportDataAsCsv();
  }

  onGridReady(event: GridReadyEvent<any>) {
    this.gridApi = event.api;
  }

  uploadFile(event: any) {
    if (event.target.files[0].type === "text/csv") {
      this.file = event?.target.files[0];
      this.formData.append('file', this.file);
      this.commonService.uploadResourceSheet(this.formData).subscribe({
        next: (res: any) => {
          this.toastr.success('Resources Sheet uploaded sucessfully', 'Success', { closeButton: true, positionClass: 'toast-center-center' });
            this.commonService.fetchResourceDetails().subscribe((res: any) => {
            //   res = {
            //     "rowData": [
            //         {
            //             "empId" : "1",
            //             "name"  : "KLN",
            //             "designation" : "Senior Software Engineer",
            //             "onboardingStatus" : "Completed",
            //             "billingStatus" : "Yes",
            //             "manager" : "Ranjith"
            //         }
            //     ],
            //     "colDefs" : [
            //         {
            //             "field": "empId",
            //             "headerName": "Emp ID"
            //         },
            //         {
            //             "field": "name",
            //             "headerName": "Associate Name"
            //         },
            //         {
            //             "field": "designation",
            //             "headerName": "Designation"
            //         },
            //         {
            //             "field": "onboardingStatus",
            //             "headerName": "Onboarding Status"
            //         },
            //         {
            //             "field": "billingStatus",
            //             "headerName": "Billing Status"
            //         },
            //         {
            //             "field": "manager",
            //             "headerName": "Manager"
            //         }
            //     ]
            // };
              this.resourceDetails = res;
              this.resourceDetails.colDefs.push({ field: 'action', headerName: 'Actions', cellRenderer: EditComponent});
            });
        },
        error: (err: any) => {
        }
      });
    } else {
      this.toastr.warning('File should be in excel/csv format', 'Upload failed', { closeButton: true, positionClass: 'toast-center-center'});
    }
 
  }
}
