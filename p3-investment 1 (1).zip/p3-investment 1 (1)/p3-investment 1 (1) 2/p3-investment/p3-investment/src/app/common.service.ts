import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {


  resourceDetails = new Subject();
  
  constructor(private http: HttpClient) { }

  uploadResourceSheet(fileData: any) {
    // return this.http.post('', fileData);
    return this.http.get('../assets/resourcesMock.json');
  }

  fetchResourceDetails() {
    return this.http.get('../assets/resourcesMock.json');
  }
}
