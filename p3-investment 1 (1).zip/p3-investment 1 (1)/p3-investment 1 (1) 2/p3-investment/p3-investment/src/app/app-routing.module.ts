import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ToolsComponent } from './tools/tools.component';
import { ResourcesComponent } from './resources/resources.component';
import { EditResourcesComponent } from './edit-resources/edit-resources.component';
import { OverviewComponent } from './overview/overview.component';
import { RegistrationComponent } from './registration/registration.component';
import { TrainingsComponent } from './trainings/trainings.component';

const routes: Routes = [
  { path: 'tools', component: ToolsComponent },
  { path: 'resources', component: ResourcesComponent },
  { path: 'edit-resources', component: EditResourcesComponent },
  { path: 'overview', component: OverviewComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'trainings', component: TrainingsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
